import csv
from collections import Counter
import hashlib
import html
import json
import re
import sys
import time
from pathlib import Path
from zoneinfo import ZoneInfo
from datetime import datetime

from policy_eval import FIELDS, LAYERS, exact_index, raw_directions, read_rows, validation

comparison_path = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=False)
session = Path(sys.argv[3]).resolve() if len(sys.argv) > 3 else Path(__file__).resolve().parent
comparison = json.loads(comparison_path.read_text())
state = json.loads((session / 'SESSION_STATUS.json').read_text())
service = json.loads((session / 'service.json').read_text())
best = comparison['best_candidate']
versions = ['baseline', best]
reports = comparison['runs']
summary = comparison['summary']
for version in versions:
    for panel in ['diagnostic', 'holdout']:
        if len([r for r in reports[version] if r['panel'] == panel]) != 3:
            raise ValueError('Final reports require all three complete baseline and best-panel repetitions')
evaluation = json.loads((session / 'baseline/evaluation.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
pct = lambda x: '—' if x is None else f'{100*x:.2f}%'

def stamp(epoch):
    return datetime.fromtimestamp(epoch, ZoneInfo('America/Los_Angeles')).isoformat(timespec='seconds')

def answer(value):
    return '/'.join(str(value.get(field, 'invalid')) for field in FIELDS)

def native(version, report):
    directory = session / version / 'runs' / report['run']
    rows = exact_index(read_rows(directory / 'critics'))
    labels = json.loads((session / version / 'labels' / f'{report["panel"]}.json').read_text())
    return directory, rows, labels

def stage_cell(metrics):
    return f'{metrics["correct_directions"]}/{metrics["directions"]}; {metrics["correct_pairs"]}/{metrics["pairs"]}'

tables = {}
means = []
repeat_rows = []
for version in versions:
    for group in ['personal120', 'development99_original', 'development99_reviewed', 'development97_strict']:
        for layer in LAYERS:
            a = summary[version][group][layer]
            means.append([version, group, layer, pct(a['direction_agreement']['mean']), pct(a['direction_agreement']['worst']), pct(a['pair_agreement']['mean']), pct(a['pair_agreement']['worst']), pct(a['valid_judgment_coverage']['mean']), pct(a['valid_judgment_coverage']['worst'])])
    for report in reports[version]:
        if report['panel'] not in {'diagnostic', 'holdout'}:
            continue
        for group, layers in report['groups'].items():
            if group == 'real_consensus6':
                continue
            repeat_rows.append([version, group, report['run'].rsplit('-', 1)[1], *[stage_cell(layers[layer]) for layer in LAYERS]])
tables['means'] = means
tables['repeats'] = repeat_rows
tables['overview'] = [row[:7] for row in means if row[2] == 'final']
req = comparison['requirements']
tables['requirements'] = [
    *[[f'hard.{name}', 'PASS' if value else 'FAIL'] for name, value in req['hard_regressions'].items()],
    ['personal120.mean80%/75%', 'PASS' if req.get('personal_targets_mean') else 'FAIL'],
    ['personal120.each-repeat80%/75%', 'PASS' if req['personal_targets_each_repeat'] else 'FAIL'],
    *[[f'nonregression.{name}', 'PASS' if value else 'FAIL'] for name, value in req['development_nonregression_mean'].items()],
]

hard = []
for version in versions:
    for group in ['original36', 'extra6', 'latest18', 'controlled26', 'real_consensus6']:
        by_repeat = {int(r['run'].rsplit('-', 1)[1]): r for r in reports[version] if group in r['groups']}
        cells = [' / '.join(f'{by_repeat[i]["groups"][group][layer]["correct_pairs"]}/{by_repeat[i]["groups"][group][layer]["pairs"]}' for layer in LAYERS) if i in by_repeat else '—' for i in (1, 2, 3)]
        hard.append([version, group, *cells])
tables['hard'] = hard
tables['swaps'] = [[r['run'], *[', '.join(r['swap_mismatches'][layer]) or '—' for layer in LAYERS]] for r in reports[best] if 'swap_mismatches' in r]

review_provenance={r['case_id']:r for r in json.loads((session/'review-provenance.json').read_text())['cases']}
latest_cases = []
regression_failures = []
case_ids = [row['case_id'] for row in evaluation['latest_user_decisions']]
case_data = {key: [] for key in case_ids}
d121_rows = []
d074_rows = []
technical = []
changes = []
truncated_rows = []
discussion_rows = []
for version in versions:
    for report in reports[version]:
        if report['panel'] in {'diagnostic', 'holdout'}:
            valid = report['all_input_validation']
            group = 'personal120' if report['panel'] == 'diagnostic' else 'development99_reviewed'
            reference = report['groups'][group]['final']
            technical.append([version, report['run'], *[f'{valid[layer].get("valid", 0)}/{valid[layer].get("invalid", 0)}/{valid[layer].get("unresolved", 0)}' for layer in LAYERS], pct(valid['final'].get('valid',0)/sum(valid['final'].get(k,0) for k in ['valid','invalid','unresolved'])), pct(reference['valid_judgment_coverage']), reference['reference_wrong_allows'], reference['reference_wrong_blocks'], json.dumps(report['attempt_status_counts'], sort_keys=True)])
            changes.append([version, report['run'], report['stage_direction_changes']['main_to_coverage'], report['stage_direction_changes']['coverage_to_final']])
            if report['panel'] == 'diagnostic':
                _, rows, _ = native(version, report)
                item = rows['D074']
                d074_rows.append([version, report['run'].rsplit('-', 1)[1], answer(raw_directions(item, 'main')), answer(validation(item, 'final', report['issues'].get('D074', []))), '; '.join(report['issues'].get('D074', [])) or '—'])
                item = rows['D121']
                d121_rows.append([version, report['run'].rsplit('-', 1)[1], *[answer(validation(item, layer, report['issues'].get('D121', []))) for layer in LAYERS]])
                for key in evaluation['truncated_ids']:
                    item = rows[key]
                    truncated_rows.append([version, report['run'].rsplit('-', 1)[1], key, answer(raw_directions(item, 'main')), answer(validation(item, 'final', report['issues'].get(key, []))), '; '.join(report['issues'].get(key, [])) or '—'])
                cells=[]
                for layer in LAYERS:
                    counts=Counter(validation(rows[key], layer, report['issues'].get(key, []))['validation_status'] for key in evaluation['discussion_ids'])
                    cells.append('/'.join(str(counts[x]) for x in ['valid','invalid','unresolved']))
                discussion_rows.append([version, report['run'].rsplit('-', 1)[1], *cells])
        if version != best or report['panel'] not in {'gate', 'coverage-regression', 'preflight'}:
            continue
        _, rows, labels = native(version, report)
        labels = exact_index(labels)
        for key, row in rows.items():
            values = {layer: validation(row, layer, report['issues'].get(key, [])) for layer in LAYERS}
            if any(any(value[field] != labels[key][field] for field in FIELDS) for value in values.values()):
                regression_failures.append([report['run'], key, answer(labels[key]), *[answer(values[layer]) for layer in LAYERS], '; '.join(report['issues'].get(key, [])) or '—'])
        if report['panel'] == 'preflight':
            repeat = int(report['run'].rsplit('-', 1)[1])
            for key in case_ids:
                counts = []
                for layer in LAYERS:
                    count = 0
                    for presented in [key, key + '-swapped']:
                        value = validation(rows[presented], layer, report['issues'].get(presented, []))
                        count += all(value[field] == labels[presented][field] for field in FIELDS)
                    counts.append(f'{count}/2')
                case_data[key].append((repeat, ' / '.join(counts)))
for row in evaluation['latest_user_decisions']:
    history=review_provenance[row['case_id']]
    original=history.get('original_reference') or {}
    proposal=history.get('assistant_proposal') or {}
    prior=history.get('initial_agent_review') or {}
    prior={f:prior.get('proposed_'+f) for f in FIELDS}
    latest_cases.append([row['case_id'], (original.get('type','reference')+': '+answer(original)) if all(original.get(f) in {'yes','no'} for f in FIELDS) else '—', answer(prior) if all(prior.get(f) in {'yes','no'} for f in FIELDS) else '—', answer(proposal) if all(proposal.get(f) in {'yes','no'} for f in FIELDS) else '—', answer(row), *[value for _, value in sorted(case_data[row['case_id']])]])
tables['truncated'] = truncated_rows
tables['discussion'] = discussion_rows
tables.update(cases=latest_cases, failures=regression_failures, technical=technical, changes=changes, d074=d074_rows, d121=d121_rows)

search = []
for version in sorted(reports):
    if version == 'baseline':
        continue
    root = session / version
    hypothesis = json.loads((root / 'hypothesis.json').read_text()) if (root / 'hypothesis.json').exists() else {}
    values = reports[version]
    cells = []
    for group in ['original36', 'extra6', 'latest18', 'controlled26']:
        one = next((r for r in values if group in r['groups'] and r['run'].endswith('-1')), None)
        cells.append('—' if one is None else ' / '.join(f'{one["groups"][group][layer]["correct_pairs"]}/{one["groups"][group][layer]["pairs"]}' for layer in LAYERS))
    search.append([version, *cells])
tables['search'] = search
tables['failed_runs'] = [[r['root'], r['run'], r['status'], r['expected_input_pairs'], r['main_output_rows'], r['http_attempts']] for r in comparison.get('failed_runs', [])]

stability = []
for version in ['candidate-02', 'candidate-03', 'candidate-04', 'candidate-06']:
    selected = [r for r in reports.get(version, []) if r['panel'] in {'gate', 'coverage-regression', 'preflight'}]
    for layer in LAYERS:
        metrics = [v[layer] for r in selected for v in r['groups'].values()]
        stability.append([version, layer, sum(v['pairs'] for v in metrics), sum(v['correct_pairs'] for v in metrics), sum(v['invalid_pairs'] for v in metrics), sum(v['unresolved_pairs'] for v in metrics), sum(v['reference_wrong_allows'] for v in metrics), sum(v['reference_wrong_blocks'] for v in metrics)])
tables['stability'] = stability
verification = json.loads((session / 'verification-final.json').read_text())
tables['verification'] = [[name, item['result'], item.get('passed', '—'), item.get('sha256', '—')] for name, item in verification['checks'].items()]
selection = json.loads((session / 'final-selection.json').read_text())

status_passed = comparison['acceptance_passed']
wall_end = time.time()
gpu_end = service.get('stopped', wall_end)
resources = [[
    stamp(state['start_time']), stamp(wall_end), stamp(state['deadline']),
    f'{(wall_end-state["start_time"])/3600:.2f}', f'{(gpu_end-service["started"])/3600:.2f}',
    '1 × NVIDIA B200', 'TP=1', '32,768', '6,144', '0.2', '8', '600', '6,000',
]]
tables['resources'] = resources
all_runs=[r for values in reports.values() for r in values]
trial_presentations=sum(sum(r['all_input_validation']['main'].get(status,0) for status in ['valid','invalid','unresolved']) for r in all_runs)
trial_attempts=sum(sum(r['attempt_status_counts'].values()) for r in all_runs)
tables['workload']=[[6,1,len(all_runs),len(comparison.get('failed_runs',[])),trial_presentations,trial_attempts]]

headers = {
    'workload': (['Semantic candidates', 'Prompt engineering revisions', 'Completed native trials', 'Failed lifecycles', 'Evaluated presentations', 'Trial HTTP attempts'], ['语义候选', '提示词工程修订', '完成的原生运行', '失败生命周期', '评测呈现数', '实验 HTTP 尝试']),
    'truncated': (['Version', 'Repeat', 'Case', 'Raw main A/B', 'Validated final A/B', 'Issues'], ['版本', '重复', '案例', '原始 main A/B', '经验证 final A/B', '问题']),
    'discussion': (['Version', 'Repeat', 'Main V/I/U', 'Coverage V/I/U', 'Final V/I/U'], ['版本', '重复', 'Main 有效/无效/待定', 'Coverage 有效/无效/待定', 'Final 有效/无效/待定']),
    'swaps': (['Run', 'Main mismatched swaps', 'Coverage mismatched swaps', 'Final mismatched swaps'], ['运行', 'Main 交换不一致', 'Coverage 交换不一致', 'Final 交换不一致']),
    'stability': (['Variant', 'Layer', 'Presentations', 'Correct pairs', 'Invalid', 'Unresolved', 'Raw wrong allows', 'Raw wrong blocks'], ['版本', '层', '呈现数', '正确整对', '无效', '待定', '原始错误允许', '原始错误阻止']),
    'verification': (['Check', 'Result', 'Passed', 'Log SHA256'], ['检查', '结果', '通过数', '日志 SHA256']),
    'overview': (['Version', 'Reference', 'Layer', 'D mean', 'D worst', 'P mean', 'P worst'], ['版本', '参考口径', '层', '方向均值', '方向最差', '整对均值', '整对最差']),
    'requirements': (['Requirement', 'Result'], ['要求', '结果']),
    'means': (['Version', 'Reference', 'Layer', 'D mean', 'D worst', 'P mean', 'P worst', 'Valid coverage mean', 'Valid coverage worst'], ['版本', '参考口径', '层', '方向均值', '方向最差', '整对均值', '整对最差', '有效判断覆盖率均值', '有效判断覆盖率最差']),
    'repeats': (['Version', 'Reference', 'Repeat', 'Main D; P', 'Coverage D; P', 'Final D; P'], ['版本', '参考口径', '重复', 'Main 方向；整对', 'Coverage 方向；整对', 'Final 方向；整对']),
    'hard': (['Version', 'Group', 'Repeat 1 M/C/F', 'Repeat 2 M/C/F', 'Repeat 3 M/C/F'], ['版本', '组', '重复1 M/C/F', '重复2 M/C/F', '重复3 M/C/F']),
    'cases': (['Case', 'Original reference A/B', 'Initial agent review A/B', 'Follow-up agent proposal A/B', 'Latest user A/B', 'Repeat 1 M/C/F', 'Repeat 2 M/C/F', 'Repeat 3 M/C/F'], ['案例', '原始参考 A/B', '初次代审 A/B', '复核前代审建议 A/B', '最新用户决定 A/B', '重复1 M/C/F', '重复2 M/C/F', '重复3 M/C/F']),
    'failures': (['Run', 'Presentation', 'Expected', 'Main', 'Coverage', 'Final', 'Issues'], ['运行', '呈现样本', '预期', 'Main', 'Coverage', 'Final', '问题']),
    'technical': (['Version', 'Run', 'Main V/I/U', 'Coverage V/I/U', 'Final V/I/U', 'Final full-input valid coverage', 'Final eligible-reference valid coverage', 'Reference wrong allows', 'Reference wrong blocks', 'HTTP attempt status'], ['版本', '运行', 'Main 有效/无效/待定', 'Coverage 有效/无效/待定', 'Final 有效/无效/待定', 'Final 全部输入有效覆盖率', 'Final 评分参考有效覆盖率', '相对参考错误允许', '相对参考错误阻止', 'HTTP 尝试状态']),
    'changes': (['Version', 'Run', 'Main→coverage changed directions', 'Coverage→final changed directions'], ['版本', '运行', 'Main→coverage 改变方向数', 'Coverage→final 改变方向数']),
    'd074': (['Version', 'Repeat', 'Raw main A/B', 'Validated final A/B', 'Issues'], ['版本', '重复', '原始 main A/B', '经验证 final A/B', '问题']),
    'd121': (['Version', 'Repeat', 'Main A/B', 'Coverage A/B', 'Final A/B'], ['版本', '重复', 'Main A/B', 'Coverage A/B', 'Final A/B']),
    'search': (['Variant', 'Original36 M/C/F', 'Extra6 M/C/F', 'Latest18 M/C/F', 'Controlled26 M/C/F'], ['版本', '原36 M/C/F', '额外6 M/C/F', '最新18 M/C/F', '受控26 M/C/F']),
    'failed_runs': (['Variant', 'Run', 'Status', 'Expected inputs', 'Main output rows', 'HTTP attempts'], ['版本', '运行', '状态', '预期输入', 'Main 输出行', 'HTTP 尝试']),
    'resources': (['Start (Los Angeles)', 'Report freeze (Los Angeles)', 'Deadline (Los Angeles)', 'Wall hours to report', 'Allocated GPU hours', 'GPU', 'TP', 'Context', 'Max output', 'Temperature', 'Max concurrency', 'Timeout seconds', 'Window chars'], ['开始（洛杉矶）', '报告冻结（洛杉矶）', '截止（洛杉矶）', '至报告墙钟小时', 'GPU 占用小时', 'GPU', 'TP', '上下文', '最大输出', '温度', '最大并发', '超时秒', '字符窗口']),
}

for name,rows in tables.items():
    assert len(headers[name][0])==len(headers[name][1]), name
    assert all(len(row)==len(headers[name][0]) for row in rows), name

texts = {
 'en': {
  'title': 'Qwen retention calibration v2 — bounded follow-up',
  'status': 'The acceptance conditions were met.' if status_passed else 'The acceptance conditions were NOT met. This is delivery of the best available version, not an acceptance claim.',
  'intro': f'Fixed baseline: `6715574e4e553f7b36f263d755f6cebe198e7b11`. Selected version: `{best}` on `codex/dedup-retention-policy-v2`. Search stopped at the authorized limit of 6 semantic candidates; the engineering-only repair of candidate 5 is separate. No seventh semantic candidate was tried.',
  'scope': 'Both replacement directions always mean A replaces B / B replaces A. All 150 discussion inputs and all 100 development inputs were rerun 3 times per final variant. These are exposed development references, not independent human accuracy or evidence of corpus deletion risk. Original round-021 files and failed attempts remain unchanged.',
  'rules': 'The final prompt asks the judge to distinguish routine localized headings/form messages from substantive body-language material, protects actual action destinations and procedural steps, applies narrow generic-template/cookie-introduction/repetition boundaries, and checks coverage across the whole keeper. It shows the same 6,000-character originals with exact one-sided CORE spans and shared reading context. The native Data Designer executor, all 15 fields and enums, evidence validation and veto-only critic authority remain intact; no dedup algorithm, quality filter or keeper selection changed. These rules target confirmed over-retention of routine localization/cookie text and unsafe replacement of changed actual submission routes.',
  'denom_title': 'Fixed references and denominators',
  'overview_title': 'Headline final-layer agreement',
  'requirements_title': 'Requirement results',
  'requirements_note': 'PASS/FAIL applies to the frozen checks. Hard regressions require every layer and every repetition; the mean reference target and the stricter each-repeat stability target remain separate.',
  'denom': 'The fixed personal reference has 120 pairs / 240 directions: 123 historical personal references minus 2 truncated pairs and pending D121, with the latest explicit review applied. The remaining 150-pair strata are 6 consensus pairs, 18 complete discussion cases, 5 truncated pairs (D146–D150), and pending D121. Discussion and truncated cases are not scored against definitive full-text labels. The 100-pair development panel has 99 pair-complete original references; H039 contains an unresolved historical direction. The reviewed 99-pair view accepts the user-approved whole-pair alternatives for H029/H052; strict reviewed agreement uses 97 pairs. Technical failures and model unresolved judgments stay incorrect within every fixed eligible denominator, and all-input failures remain counted across 150/100.',
  'means_title': 'Mean and worst agreement',
  'means_note': 'D is directional agreement; P requires both directions correct. The original and reviewed reference views are separate. Mean and worst use identical 3 repetitions. The additional each-repeat 80%/75% stability check is reported separately from the mean target. Means use exact integer-count fractions before conversion for display, so equal totals cannot become a false non-regression failure through floating-point rounding.',
  'repeat_title': 'Every repetition, all layers',
  'repeat_note': 'Each cell is correct directions / fixed directions; correct pairs / fixed pairs.',
  'hard_title': 'Hard regressions',
  'hard_note': 'M/C/F denotes main/coverage/final correct presented pairs. Every selected-variant group and repetition must pass completely; averages or majority votes cannot hide a failed presentation. The baseline hard screen has one repetition; both versions have three full diagnostic/development repetitions. The 26 controlled presentations were derived from the stated policy before tuning and are not newly obtained human gold labels.',
  'swap_title': 'A/B exchange consistency',
  'swap_note': 'Entries identify base pairs whose mapped answers differ across the two presentations. Invalid answers stay invalid and are listed in the failure table even if both orders happen to fail identically.',
  'case_title': 'Nine explicit latest reviews',
  'case_note': 'Each repetition cell is M/C/F correct presentations out of the original and swapped order (2). R14 remains a confirmed directional policy label; a model failure is not reclassified as an unsettled policy question. Original references, initial agent suggestions and user decisions remain separately frozen.',
  'failure_title': 'Remaining hard-regression failures',
  'failure_note': 'Invalid judgments remain invalid even when a retry gives semantically plausible answers. A critic correction cannot excuse an incorrect main judgment, and an unverified critic result cannot become an effective Yes.',
  'diagnosis_title': 'Observed failure mechanisms',
  'diagnosis': 'Across the search, permitted template slots and stock cookie text were still sometimes treated as concrete additions; correct main Yes answers could then be revoked by critics. Conversely, candidate 6 repetition 2 treated a real submission email as an allowed city slot in both main and coverage, despite the explicit operational-route rule. These are observed rule-execution failures, not new user decisions. Parse/evidence failures remain a separate validity problem. No post-hoc parser repair, schema relaxation or No-to-Yes critic promotion was used.',
  'technical_title': 'All-input validity and reference-relative signals',
  'technical_note': 'V/I/U is valid/invalid/unresolved pairs across the full input panel. Wrong allows/blocks are relative to personal120 or reviewed99 references, not measured corpus error rates. Raw Yes values against reference No are counted even when schema/evidence is invalid. Final valid coverage is shown for both all inputs and the fixed eligible references; invalid/unresolved judgments earn no agreement credit.',
  'changes_title': 'Layer changes',
  'd074_title': 'D074 structural-output evidence',
  'd074_note': 'The historical illegal state_or_version enum attempt and subsequent raw No/No are both retained. A later plausible answer does not erase the original technical failure. The table applies the same rule to this run.',
  'pending_title': 'D121 remains pending',
  'pending_note': 'These are observations only. D121 has no acceptance label and is excluded from the fixed personal agreement target.',
  'truncated_title': 'Five truncated inputs, observations only',
  'truncated_note': 'D146–D150 are reported separately. Partial-window observations are not compared with full-text labels. A technically valid answer on partial text does not establish full-text correctness.',
  'discussion_title': 'Eighteen complete discussion cases, unscored',
  'discussion_note': 'Only judgment validity is summarized for the fixed discussion stratum, without inventing definitive accuracy labels. V/I/U is valid/invalid/unresolved; each row covers all 18 cases.',
  'search_title': 'Search record',
  'search_note': 'Each cell shows the first full screen, with M/C/F correct pairs. Failed screens were retained. After the semantic budget was exhausted, the selected best version received the required full diagnostic repetitions; it was not promoted as having passed the screen. Candidate 5 originally failed native template compilation before any inference call; its format1 engineering revision used fresh directories and checkpoints with the same semantics.',
  'stability_title': 'Repeated selection evidence',
  'stability_note': 'The frozen second, third, fourth and sixth candidates received the same 86 hard presentations in 3 independent repetitions. Selection considers validity and retention-required wrong allows before development-reference scores. These totals are descriptive selection evidence, never a majority-vote acceptance. The exact selection rationale is preserved in final-selection.json.',
  'verification_title': 'Engineering verification',
  'verification_note': 'Tests used the existing Data Designer 0.9.1 environment. GPU checks were registered and limited to the single owned service. The final manifest verifies the exact 9-file fixed-baseline match after the shared native format adapter, source paths, frozen inputs, prompt round-trip hashes, native receipts and the unchanged executor/validator/critic Python modules. Pre-commit evidence is delivered separately with the final verification receipt.',
  'failed_title': 'Failed execution lifecycles',
  'workload_title': 'Bounded experiment workload',
  'workload_note': 'These counts cover all retained native experiment trials, including rejected variants and repetitions. Registered GPU checks are reported separately; tokenizer checks made no generation calls. Compile-before-inference failure has zero evaluated outputs and remains in the failed lifecycle table.',
  'resource_title': 'Time and resources',
  'resource_note': 'The model is local Qwen3.8-27B-FP8, revision 017b9c7af6b5689d5dd426a76e0bc077eb5ca20a, served with the verified round-021 image. Only the owned GPU0 service was managed. Allocation includes setup and idle time; tokenizer checks made no generation calls. Start/deadline stayed fixed across the run, and a deadline guard reserved shutdown time.',
  'next_title': 'Next smallest step',
  'next': 'Resolve the remaining general-rule execution and structured-output instability against these preserved failures before treating the version as accepted. Keep D121 pending until the user decides it. New 20K and Deciffusion comparisons remain follow-up work. New independent acceptance would require unexposed human review material.',
  'repro_title': 'Artifacts and reproduction',
  'repro': f'Full frozen inputs, directions, reference provenance, every variant diff/prompt hash, native HTTP traces, source snapshots and per-run JSON/CSV/HTML are in `{session}`. Machine comparison: `{comparison_path}`. Use the existing `/raid/hfang/llm_judge_env_pr2324_latest` environment with Data Designer 0.9.1; do not create/sync another environment. Reproduce reports with the command below and a new output directory. The versioned repository entry is `tutorials/eval/dedup/calibration/round-022-v2/README.md`; its archive contains all six frozen prompt versions, per-run JSON/CSV/HTML, the report renderer and an exact-profile replay script. Inference requires a fresh run directory and the exact recorded owned-service profile; `policy_tuning.py execute` invokes the original `policy_eval.py run` workflow.',
 },
 'zh': {
  'title': 'Qwen 保留规则校准 v2 — 有预算的后续调优',
  'status': '已达到验收条件。' if status_passed else '未达到验收条件。本次交付最佳可用版本，不宣称验收通过。',
  'intro': f'固定基线：`6715574e4e553f7b36f263d755f6cebe198e7b11`。选定版本：`{best}`，分支为 `codex/dedup-retention-policy-v2`。搜索在授权的 6 个语义候选上限停止；候选 5 的纯工程修复单独记录。没有尝试第七个语义候选。',
  'scope': '两个替换方向始终为 A替代B / B替代A。最终两版均完整重跑全部 150 对讨论输入和全部 100 对开发输入，各 3 次。这些是已暴露的开发参考，不是独立人工准确率，也不能证明真实语料误删率。原 round-021 文件及失败尝试均保持不变。',
  'rules': '最终提示词区分常规本地化标题/表单消息与有实质贡献的正文语言材料，保护实际操作入口和流程步骤，按条件处理通用模板、cookie 引言和重复文字，并对整个保留文本核查覆盖。它展示相同的 6,000 字符原文窗口，标清真正单侧的 CORE 差异及共享阅读上下文。原生 Data Designer 执行器、全部 15 个字段及枚举、证据验证和只能否决的 critic 权限均保留；没有改变 dedup 算法、质量过滤或 keeper 选择。这些规则针对已确认的常规本地化/cookie 文字过度保留，以及实际投稿入口变化被错误放行的问题。',
  'denom_title': '固定参考与分母',
  'overview_title': 'Final 层关键参考一致率',
  'requirements_title': '要求核对结果',
  'requirements_note': 'PASS/FAIL 为冻结检查的通过/未通过结果。硬性回归要求每层、每次均通过；参考均值目标与更严格的每次重复稳定性目标分开显示。',
  'denom': '固定个人参考为 120 对 / 240 个方向：123 对历史个人参考，减去 2 对截断样本和待定的 D121，再应用最新明确复核。150 对中的其他分层为 6 对共识、18 对未截断待讨论案例、5 对截断样本（D146–D150）以及待定的 D121。待讨论和截断案例不按确定全文标签评分。100 对开发材料有 99 对完整原始参考；H039 含一个历史待定方向。复核后 99 对口径接受用户允许的 H029/H052 整对备选答案；严格复核口径为 97 对。技术失败和模型 unresolved 在每个固定可评分分母内仍计为错误，全部输入的失败仍按 150/100 对统计。',
  'means_title': '均值与最差参考一致率',
  'means_note': 'D 为方向一致率；P 要求两个方向都正确。原始与复核参考分开报告。均值和最差值采用相同的 3 次重复。额外的每次重复均达到 80%/75% 稳定性检查，与均值目标分开报告。均值先按整数计数的精确分数计算，再转换显示，避免相同总数因浮点舍入被误判为退步。',
  'repeat_title': '每次重复、全部层',
  'repeat_note': '每个单元格为正确方向数 / 固定方向数；正确整对数 / 固定对数。',
  'hard_title': '硬性回归',
  'hard_note': 'M/C/F 为 main/coverage/final 正确呈现对数。选定版本的每组、每次重复都必须完整通过；不能用均值或多数投票掩盖失败。基线硬性筛查运行一次；两版完整诊断/开发集均运行三次。26 个受控呈现样本在调优前按既定政策构造，不是新取得的人工金标准。',
  'swap_title': 'A/B 交换一致性',
  'swap_note': '列出交换前后映射答案不一致的基础样本。无效答案继续保持无效；即使两个顺序恰好同样失败，也会列入失败表。',
  'case_title': '九项最新明确复核',
  'case_note': '每次重复单元格为原顺序及交换顺序（2）的 M/C/F 正确呈现数。R14 仍是已确认的方向性政策标签；模型失败不会被改称为政策待定。原始参考、初次代审建议和用户决定分别冻结保留。',
  'failure_title': '尚未通过的硬性回归',
  'failure_note': '无效判断继续保持无效，即使重试后给出语义上看似合理的答案。critic 的纠正不能免除主判错误，未经验证的 critic 结果也不能成为有效 Yes。',
  'diagnosis_title': '观察到的失败机制',
  'diagnosis': '搜索过程中，允许的模板槽位和通用 cookie 文字仍有时被当作具体新增内容；主判正确的 Yes 随后可能被 critic 否决。反过来，第 6 版第 2 次重复的 main 和 coverage 都把实际投稿邮箱当成允许的城市槽位，尽管规则明确保护实际操作入口。这些是观察到的规则执行失败，不是新的用户政策决定。解析/证据失败另作为有效性问题保留。没有进行事后解析器修补、放宽结构约束或允许 critic 将 No 升为 Yes。',
  'technical_title': '全部输入的有效性与相对参考信号',
  'technical_note': 'V/I/U 为全部输入中的有效/无效/unresolved 对数。错误允许/阻止是相对 personal120 或 reviewed99 参考的信号，不是真实语料错误率。参考为 No 的方向中，原始 Yes 即使字段或证据无效仍计入信号。Final 有效覆盖率分别按全部输入和固定可评分参考列出；无效/unresolved 判断不获得一致率分数。',
  'changes_title': '各层改变',
  'd074_title': 'D074 结构化输出证据',
  'd074_note': '历史非法 state_or_version 枚举尝试及其后的原始 No/No 都保留。后来的合理答案不能抹掉原始技术失败。本表对本轮运行采用相同规则。',
  'pending_title': 'D121 保持待定',
  'pending_note': '这里只展示观察结果。D121 没有验收标签，并从固定个人参考一致率目标中排除。',
  'truncated_title': '五对截断输入，仅作观察',
  'truncated_note': 'D146–D150 单独报告。不将部分窗口观察结果与全文标签计算一致率。部分文本上技术有效的答案，不能证明全文判断正确。',
  'discussion_title': '十八对未截断待讨论案例，不计一致率',
  'discussion_note': '这里只汇总固定待讨论分层的判断有效性，不虚构确定的准确率标签。V/I/U 为有效/无效/unresolved；每行包含全部 18 对。',
  'search_title': '搜索记录',
  'search_note': '每个单元格展示首次完整筛查的 M/C/F 正确对数，失败筛查全部保留。语义预算用尽后，选定的最佳版本仍完成要求的完整诊断重复，不将其升级为“筛查已通过”。候选 5 最初在任何推理调用前即未通过原生模板编译；其 format1 工程修订采用新目录和新 checkpoint，语义规则相同。',
  'stability_title': '重复选优证据',
  'stability_note': '冻结的第 2、3、4、6 版采用相同的 86 个硬性呈现样本，独立重复 3 次。选优先考虑有效性和应保留方向的错误允许，再考虑开发参考分数。这些总数用于描述选优证据，不能作为多数投票验收。准确的选择理由保存在 final-selection.json。',
  'verification_title': '工程验证',
  'verification_note': '测试使用已有 Data Designer 0.9.1 环境。GPU 检查单独注册，仅使用本任务的单卡服务。最终清单核查固定基线经共同原生格式适配后的 9 个文件逐一精确匹配、代码路径、冻结输入、提示词往返哈希、原生凭据及未改变的执行器/校验器/critic Python 模块。Pre-commit 证据随最终验证凭据单独交付。',
  'failed_title': '失败的执行生命周期',
  'workload_title': '有界实验工作量',
  'workload_note': '这些数量覆盖全部保留的原生实验运行，包括淘汰版本和重复。单独注册的 GPU 检查另行报告；tokenizer 检查没有生成调用。推理前编译失败的有效输出为零，并保留在失败生命周期表中。',
  'resource_title': '时间与资源',
  'resource_note': '模型为本地 Qwen3.8-27B-FP8，revision 为 017b9c7af6b5689d5dd426a76e0bc077eb5ca20a，使用 round-021 已验证镜像。只管理本任务 GPU0 服务。占用时间包括启动及空闲时间；tokenizer 检查没有生成调用。运行期间开始/截止时间始终固定，并由期限保护预留关闭时间。',
  'next_title': '最小下一步',
  'next': '在将该版本视作通过验收之前，先根据保留的失败证据解决剩余通用规则执行及结构化输出稳定性问题。D121 在用户决定前继续待定。新 20K 与 Deciffusion 对照保留为后续工作。新的独立验收需要未暴露的人工复核材料。',
  'repro_title': '交付材料与复现',
  'repro': f'完整冻结输入、方向、参考来源、每版 diff/prompt 哈希、原生 HTTP 轨迹、源代码快照以及逐运行 JSON/CSV/HTML 位于 `{session}`。机器对照为 `{comparison_path}`。使用已有 `/raid/hfang/llm_judge_env_pr2324_latest` 环境及 Data Designer 0.9.1，不创建或同步其他环境。采用以下命令和新的输出目录复现报告。仓库版本化入口为 `tutorials/eval/dedup/calibration/round-022-v2/README.md`；其中的归档含六个冻结提示词版本、逐运行 JSON/CSV/HTML、报告生成器及同配置重放脚本。重新推理必须使用新运行目录和记录的同口径自有服务配置；`policy_tuning.py execute` 调用原有 `policy_eval.py run` 工作流。',
 },
}

texts['en']['intro'] += ' ' + selection['reason_en']
texts['zh']['intro'] += ' ' + selection['reason_zh']
if best == 'candidate-02':
    texts['en']['next'] = 'With a separately authorized prompt budget, first address the remaining marketing/provider-slot and authentication-localization false blocks on the small frozen 86-presentation panel. Preserve the actual submission-route negatives and require all layers to pass in all 3 repetitions before another full development comparison. ' + texts['en']['next']
    texts['zh']['next'] = '在另行授权的提示词预算中，先用冻结的 86 个小型呈现样本处理剩余营销/提供商槽位和认证本地化误阻止。保留实际投稿入口反例；所有层连续 3 次全部通过后，再做完整开发对照。' + texts['zh']['next']
    texts['en']['rules'] = texts['en']['rules'].replace('It shows the same 6,000-character originals with exact one-sided CORE spans and shared reading context. ', 'It uses the frozen span packet derived from the same 6,000-character compatibility window. ')
    texts['zh']['rules'] = texts['zh']['rules'].replace('它展示相同的 6,000 字符原文窗口，标清真正单侧的 CORE 差异及共享阅读上下文。', '它使用由相同 6,000 字符兼容窗口生成的冻结 span packet。')

order = [
 ('overview_title', None, 'overview'), ('requirements_title', 'requirements_note', 'requirements'),
 ('denom_title', 'denom', None), ('means_title', 'means_note', 'means'),
 ('repeat_title', 'repeat_note', 'repeats'), ('hard_title', 'hard_note', 'hard'),
 ('swap_title', 'swap_note', 'swaps'), ('case_title', 'case_note', 'cases'), ('failure_title', 'failure_note', 'failures'),
 ('diagnosis_title', 'diagnosis', None), ('technical_title', 'technical_note', 'technical'), ('changes_title', None, 'changes'),
 ('d074_title', 'd074_note', 'd074'), ('pending_title', 'pending_note', 'd121'),
 ('truncated_title', 'truncated_note', 'truncated'), ('discussion_title', 'discussion_note', 'discussion'),
 ('search_title', 'search_note', 'search'), ('stability_title', 'stability_note', 'stability'), ('failed_title', None, 'failed_runs'),
 ('verification_title', 'verification_note', 'verification'),
 ('workload_title', 'workload_note', 'workload'), ('resource_title', 'resource_note', 'resources'), ('next_title', 'next', None),
 ('repro_title', 'repro', None),
]

def md_table(header, rows):
    if not rows:
        return '—\n'
    clean = lambda x: str(x).replace('|', '\\|').replace('\n', ' ').replace('{', '&#123;').replace('}', '&#125;')
    return '| ' + ' | '.join(header) + ' |\n| ' + ' | '.join(['---'] * len(header)) + ' |\n' + ''.join('| ' + ' | '.join(clean(x) for x in row) + ' |\n' for row in rows)

def html_table(header, rows):
    return '<div class="scroll"><table><thead><tr>' + ''.join('<th>'+html.escape(x)+'</th>' for x in header) + '</tr></thead><tbody>' + ''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows) + '</tbody></table></div>'

command = f'''export PATH=/raid/hfang/llm_judge_env_pr2324_latest/bin:$PATH
export PYTHONPATH=/raid/hfang/workspaces/Curator-retention-policy-v2/tutorials/eval/dedup:/raid/hfang/workspaces/Curator-retention-policy-v2
python tutorials/eval/dedup/policy_tuning.py compare \\
  --session {session} --best {int(best[10:12])} \\
  --best-root {best} --output NEW_UNIQUE_REPORT_DIRECTORY'''
for index, lang in enumerate(['en', 'zh']):
    t = texts[lang]
    md = f'---\ntitle: "{t["title"]}"\ndescription: "{t["status"]}"\n---\n\n' + '\n\n'.join(t[key] for key in ['status','intro','scope','rules']) + '\n\n'
    page = '<!doctype html><html lang="'+lang+'"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(t['title'])+'</title><style>body{font:15px system-ui;line-height:1.55;max-width:1500px;margin:30px auto;padding:0 24px;color:#1e293b}h1,h2{color:#123447}table{border-collapse:collapse;font-size:13px;width:100%}td,th{border:1px solid #cbd5e1;padding:7px;text-align:left;vertical-align:top}th{background:#edf3f8}.scroll{overflow:auto;margin-bottom:28px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#edf3f8;padding:18px}.status{padding:16px;border-left:5px solid #c56c20;background:#fff6e8}</style><h1>'+html.escape(t['title'])+'</h1><p class="status">'+html.escape(t['status'])+'</p>'
    page += ''.join('<p>'+html.escape(t[key])+'</p>' for key in ['intro','scope','rules'])
    for title, note, key in order:
        collapsed = key in {'means','repeats','swaps','failures','technical','changes','d074','d121','truncated','discussion','search','stability','failed_runs','verification'}
        md += ('<details>\n<summary>'+t[title]+'</summary>\n\n') if collapsed else ('## ' + t[title] + '\n\n')
        page += ('<details><summary>'+html.escape(t[title])+'</summary>') if collapsed else ('<h2>'+html.escape(t[title])+'</h2>')
        if note:
            md += t[note] + '\n\n'
            page += '<p>'+html.escape(t[note])+'</p>'
        if key:
            md += md_table(headers[key][index], tables[key]) + '\n'
            page += html_table(headers[key][index], tables[key])
        if collapsed:
            md += '</details>\n\n'
            page += '</details>'
    md += '```bash\n'+command+'\n```\n'
    page += '<pre>'+html.escape(command)+'</pre></html>'
    (out/f'report_{lang}.mdx').write_text(md)
    (out/f'report_{lang}.html').write_text(page)

en = (out/'report_en.mdx').read_text()
zh = (out/'report_zh.mdx').read_text()
en_tables = [line for line in en.splitlines() if line.startswith('| ') and not line.startswith('| ---')]
zh_tables = [line for line in zh.splitlines() if line.startswith('| ') and not line.startswith('| ---')]
en_values = [re.findall(r'\d+(?:\.\d+)?', line) for line in en_tables]
zh_values = [re.findall(r'\d+(?:\.\d+)?', line) for line in zh_tables]
validation_result = {'common_table_data_sha256': hashlib.sha256(json.dumps(tables,sort_keys=True).encode()).hexdigest(), 'shared_table_data': True, 'table_shapes_verified': True, 'same_number_of_tables_and_rows': len(en_tables)==len(zh_tables), 'numeric_table_values_identical':en_values==zh_values,'english_sha256':sha(out/'report_en.mdx'),'chinese_sha256':sha(out/'report_zh.mdx'),'comparison_sha256':sha(comparison_path),'same_ordered_sections':True}
assert validation_result['same_number_of_tables_and_rows']
assert validation_result['numeric_table_values_identical']
(out/'translation_validation.json').write_text(json.dumps(validation_result,indent=2)+'\n')
(out/'report_tables.json').write_text(json.dumps(tables,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(out),'accepted':status_passed,'best':best,'regression_failure_rows':len(regression_failures),'translation_validation':validation_result}),flush=True)
