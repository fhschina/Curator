"""Package compact audit evidence; raw text/checkpoints/traces stay in the session."""
import argparse
import csv
import html
import io
import hashlib
import json
import shutil
import subprocess
import time
import zipfile
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--comparison', type=Path, required=True)
p.add_argument('--human', type=Path, required=True)
p.add_argument('--checkout', type=Path, required=True)
a=p.parse_args()
session=Path(__file__).resolve().parent
repo=a.checkout.resolve()
dest=repo/'tutorials/eval/dedup/calibration/round-022-v2'
dest.mkdir(parents=True, exist_ok=False)
sha=lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
read=lambda path: json.loads(Path(path).read_text())
write=lambda path,value: Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
comparison=read(a.comparison)
best=comparison['best_candidate']
selection=read(session/'final-selection.json')
assert selection['best_candidate']==best
summary={k:v for k,v in comparison.items() if k!='runs'}
write(dest/'summary.json',summary)
for filename in ['comparison.csv','comparison.html']:
    shutil.copy2(a.comparison.parent/filename,dest/filename)
for filename in ['report_en.html','report_zh.html','report_tables.json','translation_validation.json']:
    shutil.copy2(a.human/filename,dest/filename)
for filename in ['frozen-evaluation-protocol.json','frozen_sources.json','engineering-changes.json','final-selection.json','verification-final.json','delivery-prompt-roundtrip.json','stability-selection-protocol.json','service.json','historical-projection.json','fixed-baseline-roundtrip.json','review-provenance.json','baseline-context-budget.json','candidate03-frozen-context-check.json','candidate06-frozen-context-check.json','gpu-usage.csv']:
    shutil.copy2(session/filename,dest/filename)
(dest/'checks').mkdir()
verification=read(session/'verification-final.json')
for check in verification['checks'].values():
    shutil.copy2(check['log'],dest/'checks'/Path(check['log']).name)
shutil.copy2(session/'gpu-checks.json',dest/'checks/gpu-checks.json')
for lang in ['en','zh']:
    shutil.copy2(a.human/f'report_{lang}.mdx',repo/f'fern/versions/main/pages/curate-text/process-data/deduplication/retention-policy-v2-report-{lang}.mdx')

roots=[session/'baseline',*sorted(x for x in session.glob('candidate-*') if x.is_dir())]
run_evidence=[]
with zipfile.ZipFile(dest/'frozen-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for filename in ['render_bilingual.py','replay_frozen.py','service.py','deadline_guard.py','check_main_budget.py','package_delivery.py','select_existing.py','collect_verification.py','write_readme.py','verify_delivery_prompts.py','finalize_manifest.py','run_registered_gpu_checks.py']:
        z.write(session/filename,'tools/'+filename)
    z.write(a.comparison,'delivery/comparison.json')
    for item in comparison.get('failed_runs', []):
        prefix=item['root']+'/runs/'+item['run']+'/execution_failure'
        payload=json.dumps(item,ensure_ascii=False,indent=2)+'\n'
        z.writestr(prefix+'.json',payload)
        stream=io.StringIO()
        writer=csv.DictWriter(stream,fieldnames=list(item))
        writer.writeheader();writer.writerow(item)
        z.writestr(prefix+'.csv',stream.getvalue())
        z.writestr(prefix+'.html','<!doctype html><meta charset="utf-8"><title>Failed execution lifecycle</title><pre>'+html.escape(payload)+'</pre>')
    for root in roots:
        for filename in ['manifest.json','evaluation.json','hypothesis.json','candidate.diff','selection.json','adjudications.json','agent_votes.json']:
            if (root/filename).exists(): z.write(root/filename,root.name+'/'+filename)
        for parent in ['variants','input_indexes','labels']:
            for path in sorted((root/parent).rglob('*')):
                if path.is_file() and 'full20k' not in str(path.relative_to(root)):
                    z.write(path,str(path.relative_to(session)))
        for path in sorted((root/'runs').glob('*/run_manifest.json')):
            directory=path.parent
            lifecycle=read(path)
            evidence={'variant':root.name,'run':directory.name,'status':lifecycle['status'],'run_manifest_sha256':sha(path),'run_manifest_code_files':lifecycle['code_files'],'driver_environment':lifecycle['environment'],'model_revision':lifecycle['model_revision'],'judge_config_sha256':lifecycle['judge_config_sha256'],'serving_container_id':lifecycle.get('serving_container',{}).get('container_id'),'serving_image_id':lifecycle.get('serving_container',{}).get('image_id'),'input_dispatch_files':lifecycle.get('input_dispatch_files',{}),'worker_environments':[], 'started':lifecycle['started'],'completed':lifecycle.get('completed')}
            for worker in sorted((directory/'environment').glob('*.json')):
                receipt=read(worker)
                assert receipt['data_designer']=='0.9.1'
                assert receipt['curator_source'].startswith(str(repo)+'/')
                evidence['worker_environments'].append(receipt)
                z.write(worker,str(worker.relative_to(session)))
            assert lifecycle['environment']['data_designer']=='0.9.1'
            assert lifecycle['environment']['curator_source'].startswith(str(repo)+'/')
            for filename in ['run_manifest.json','judge.yaml','report.json','tuning_audit-v2.json','tuning_audit-v2.csv','tuning_audit-v2.html']:
                path2=directory/filename
                if path2.exists(): z.write(path2,str(path2.relative_to(session)))
            if lifecycle['status']=='complete':
                report=read(directory/'report.json')
                assert not report['integrity_failures'] and not report['unmapped_attempts']
                for filename,checksum in report['output_files'].items():
                    assert sha(filename)==checksum
                evidence['native_report_sha256']=sha(directory/'report.json')
                evidence['outputs']=report['output_files']
                evidence['replica_peak_concurrency']=report['replica_peak_concurrency']
                assert report['replica_peak_concurrency']<=8
            run_evidence.append(evidence)
archive=dest/'frozen-evidence.zip'
if archive.stat().st_size>=950*1024:
    with zipfile.ZipFile(archive) as original:
        groups={}
        for name in original.namelist():
            prefix=name.split('/',1)[0]
            group=prefix if prefix.startswith(('baseline','candidate-')) else 'reproduction'
            groups.setdefault(group,[]).append(name)
        for group,names in groups.items():
            with zipfile.ZipFile(dest/f'evidence-{group}.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as part:
                for name in names: part.writestr(name,original.read(name))
    archive.unlink()
write(dest/'run-provenance.json',run_evidence)

native_files=read(next((session/'baseline/runs').glob('*/run_manifest.json')))['code_files']
unchanged={}
for filename in native_files:
    path=Path(filename)
    if path.name=='policy_tuning.py':continue
    relative=path.relative_to(repo)
    content=subprocess.check_output(['git','show',f'6715574e:{relative}'],cwd=repo)
    assert content==path.read_bytes(),relative
    unchanged[str(relative)]=sha(path)
for evidence in run_evidence:
    for filename,checksum in evidence['run_manifest_code_files'].items():
        relative=str(Path(filename).relative_to(repo))
        if Path(filename).name!='policy_tuning.py':assert unchanged[relative]==checksum,(evidence['run'],relative)
completed=sorted((r['started'],r['completed'],r['variant']+'/'+r['run']) for r in run_evidence if r['completed'] is not None)
assert all(nxt[0]>=prev[1] for prev,nxt in zip(completed,completed[1:])), 'Experiment inference runs overlapped'
variants={root.name:{str(path.relative_to(root/'variants')):sha(path) for path in sorted((root/'variants').rglob('*')) if path.is_file()} for root in roots}
service=read(session/'service.json')
assert 'stopped' in service and service['allocated_gpu_hours']<10
manifest={'schema':'retention-policy-v2-delivery-1','budget':{key:value for key,value in read(session/'SESSION_STATUS.json').items() if key in {'start_time','start_time_utc','deadline','deadline_utc','max_gpus','max_semantic_candidates','semantic_search_deadline'}},'created':time.time(),'baseline_commit':comparison['baseline_commit'],'best_candidate':best,'acceptance_passed':comparison['acceptance_passed'],'D121':'pending','semantic_candidates':6,'engineering_revisions':['candidate-05-format1'],'session':str(session),'source_file_hashes':read(session/'frozen_sources.json'),'fixed_evaluation_sha256':sha(session/'frozen-evaluation-protocol.json'),'fixed_artifact_hashes':comparison['frozen_evaluation_artifacts'],'variant_files':variants,'unchanged_native_python':unchanged,'audit_code_sha256':comparison['audit_sha256'],'native_trials_serial':True,'observed_peak_replica_concurrency':max(e.get('replica_peak_concurrency',0) for e in run_evidence),'full_comparison_sha256':sha(a.comparison),'service':service,'raw_artifacts':'Local session only; no raw corpus, HTTP bodies or checkpoints are committed','files':{str(path.relative_to(dest)):sha(path) for path in sorted(dest.rglob('*')) if path.is_file()}}
write(dest/'manifest.json',manifest)
assert all(path.stat().st_size<1000*1024 for path in dest.rglob('*') if path.is_file()),[(str(p),p.stat().st_size) for p in dest.rglob('*') if p.is_file()]
print(json.dumps({'destination':str(dest),'files':len(manifest['files'])+1,'native_runs':len(run_evidence),'archive_bytes':sum(p.stat().st_size for p in dest.glob('*.zip')),'acceptance_passed':comparison['acceptance_passed']}))
