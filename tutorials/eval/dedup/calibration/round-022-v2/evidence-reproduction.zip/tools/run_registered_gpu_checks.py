import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

s=Path(__file__).resolve().parent
repo=Path('/raid/hfang/workspaces/Curator-retention-policy-v2')
state=json.loads((s/'SESSION_STATUS.json').read_text())
while not (s/'FINAL_INFERENCE_COMPLETE.json').exists():
 if time.time()>=state['deadline']-60:raise TimeoutError('No final inference completion before shutdown reserve')
 time.sleep(5)
time.sleep(2)
assert sys.prefix=='/raid/hfang/llm_judge_env_pr2324_latest'
assert not (s/'gpu-checks.json').exists()
log=s/'registered-single-gpu-checks.log'
assert not log.exists()
env={**os.environ,'PATH':str(Path(sys.executable).parent)+':'+os.environ['PATH'],'PYTHONPATH':str(repo/'tutorials/eval/dedup')+':'+str(repo),'CUDA_VISIBLE_DEVICES':'0','RETENTION_QWEN_ENDPOINT':'http://127.0.0.1:18821/v1'}
command=[sys.executable,'-m','pytest','tests/tutorials/eval/dedup','--confcutdir=tests/tutorials/eval/dedup','-m','gpu','-k','not eight_replica','-q']
started=time.time()
with log.open('w') as stream:
 try:
  result=subprocess.run(command,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=max(1,state['deadline']-time.time()-60))
  code=result.returncode
 except subprocess.TimeoutExpired:
  code=124
text=log.read_text()
matched=re.search(r'(\d+) passed',text)
receipt={'started':started,'completed':time.time(),'exit_code':code,'passed':int(matched.group(1)) if matched else 0,'command':command,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'selected':json.loads((s/'final-selection.json').read_text())['best_candidate'],'prompt_roundtrip_receipt_sha256':hashlib.sha256((s/'delivery-prompt-roundtrip.json').read_bytes()).hexdigest(),'data_designer':'0.9.1','gpu_scope':'Single owned GPU0 service; registered eight-replica check excluded'}
(s/'gpu-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
if code==0 and receipt['passed']==4:
 subprocess.run([sys.executable,str(s/'collect_verification.py')],cwd=repo,env=env,check=True)
 (s/'STOP_SERVICE').touch()
 (s/'FINAL_VALIDATION_COMPLETE.json').write_text(json.dumps({'completed':time.time(),'cpu_passed':125,'gpu_passed':4,'owned_service_shutdown_requested':True})+'\n')
 print('VALIDATION_COMPLETE_SHUTDOWN_REQUESTED',flush=True)
else:
 raise RuntimeError('Registered GPU validation did not pass all four checks; evidence retained for diagnosis')
