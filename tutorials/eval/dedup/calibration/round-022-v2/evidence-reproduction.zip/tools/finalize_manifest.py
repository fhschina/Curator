import argparse
import hashlib
import json
import subprocess
import time
import zipfile
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--hook-log',type=Path)
a=p.parse_args()
s=Path(__file__).resolve().parent
repo=Path('/raid/hfang/workspaces/Curator-retention-policy-v2')
d=repo/'tutorials/eval/dedup/calibration/round-022-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
manifest=read(d/'manifest.json')
if a.hook_log:
 text=a.hook_log.read_text()
 assert 'Failed' not in text and 'Passed' in text
 target=d/'checks/precommit-final.log';target.write_bytes(a.hook_log.read_bytes())
 receipt={'result':'PASS','log':str(a.hook_log.resolve()),'sha256':sha(target),'scope':'All staged changed source and delivery files before the receipt/checksum refresh; a final full hook rerun verifies the refreshed metadata as well','checked_at':time.time()}
 (d/'checks/precommit-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
translation=read(d/'translation_validation.json')
for lang,key in [('en','english_sha256'),('zh','chinese_sha256')]:
 assert sha(repo/f'fern/versions/main/pages/curate-text/process-data/deduplication/retention-policy-v2-report-{lang}.mdx')==translation[key]
assert sha(repo/'tutorials/eval/dedup/policy_tuning.py')==read(d/'summary.json')['audit_sha256']
for z in d.glob('*.zip'):
 with zipfile.ZipFile(z) as archive:assert archive.testzip() is None,z
changed=subprocess.check_output(['git','diff','--name-only','6715574e'],cwd=repo,text=True).splitlines()
manifest['source_delivery_files']={f:sha(repo/f) for f in changed if not f.startswith('tutorials/eval/dedup/calibration/round-022-v2/')}
manifest['files']={str(p.relative_to(d)):sha(p) for p in sorted(d.rglob('*')) if p.is_file() and p.name!='manifest.json'}
manifest['finalized_at']=time.time()
(d/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files_verified':len(manifest['files']),'source_files':len(manifest['source_delivery_files']),'best':manifest['best_candidate'],'acceptance_passed':manifest['acceptance_passed']}))
