"""Select only from frozen variants using repeated hard evidence before B scores."""
import argparse
import hashlib
import json
import time
from pathlib import Path

from policy_tuning import audit_run

s=Path(__file__).resolve().parent
assert (s/'stability-validation-complete.json').exists()
metrics={}
for n in [2,3,4,6]:
 root=s/f'candidate-{n:02d}'
 reports=[]
 for panel in ['gate','coverage-regression','preflight']:
  for repeat in [1,2,3]:
   reports.append(audit_run(argparse.Namespace(root=root,name=f'candidate-{panel}-{repeat}')))
 totals={layer:{key:0 for key in ['pairs','correct_directions','correct_pairs','invalid_pairs','unresolved_pairs','reference_wrong_allows','reference_wrong_blocks']} for layer in ['main','coverage','final']}
 for report in reports:
  assert not report['integrity_failures'] and not report['unmapped_attempts']
  for layers in report['groups'].values():
   for layer,values in layers.items():
    for key in totals[layer]:totals[layer][key]+=values[key]
 assert all(row['pairs']==258 for row in totals.values())
 metrics[root.name]={'layers':totals,'valid_and_zero_wrong_allows':all(row['invalid_pairs']==row['unresolved_pairs']==row['reference_wrong_allows']==0 for row in totals.values()),'correct_all_layer_directions':sum(row['correct_directions'] for row in totals.values()),'hard_passed':all(row['correct_pairs']==258 for row in totals.values())}
eligible=[name for name,value in metrics.items() if value['valid_and_zero_wrong_allows']]
(s/'repeated-hard-selection-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
if not eligible:
 raise RuntimeError('No fully valid zero-wrong-allow candidate; inspect preserved metrics and explain the unqualified selection explicitly')
best=max(eligible,key=lambda name:metrics[name]['correct_all_layer_directions'])
reason_en=f'{best} was selected from the frozen alternatives because it preserved complete technical validity and zero observed reference-required wrong allows at every layer across all 258 hard presentations. Among variants meeting those two conditions, it had the greatest correct directional coverage. Other required-Yes mistakes still fail the hard gate; no version is promoted by majority vote. The ranking uses hard evidence only; development-reference improvement cannot excuse hard failures.'
reason_zh=f'选择冻结的 {best}，是因为它在全部 258 个硬性呈现样本的每层中保持技术有效，且相对明确应保留参考的错误允许为零。在满足这两个条件的版本中，它的正确方向覆盖最多。其余必须为 Yes 的判断仍有错误，因此硬性条件未通过；不以多数投票宣布通过。选优排序只使用硬性证据；开发参考分数改善不能免除硬性失败。'
result={'best_candidate':best,'acceptance_passed':False,'created':time.time(),'based_on':'Repeated hard evidence only; development scores excluded from ranking','reason_en':reason_en,'reason_zh':reason_zh,'selection_protocol_sha256':hashlib.sha256((s/'stability-selection-protocol.json').read_bytes()).hexdigest(),'metrics':metrics,'new_semantic_candidates':0}
(s/'final-selection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
