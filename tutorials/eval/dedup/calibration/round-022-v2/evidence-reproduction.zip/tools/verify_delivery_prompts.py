import argparse
import hashlib
import json
import shutil
import tempfile
from pathlib import Path

from policy_eval import freeze_variant

p=argparse.ArgumentParser()
p.add_argument('--sync',action='store_true')
a=p.parse_args()
s=Path(__file__).resolve().parent
repo=Path('/raid/hfang/workspaces/Curator-retention-policy-v2')
best=json.loads((s/'final-selection.json').read_text())['best_candidate']
frozen=s/best/'variants/candidate'
files=[p for p in frozen.rglob('*') if p.is_file()]
assert len(files)==9
for file in files:
 relative=file.relative_to(frozen)
 target=repo/'tutorials/eval/dedup'/relative if relative.parts[0]=='judge_config' else repo/'tutorials/eval/dedup/critics/prompts'/relative.name
 if a.sync:shutil.copy2(file,target)
 assert file.read_bytes()==target.read_bytes(),target
check=Path(tempfile.mkdtemp(prefix='delivery-roundtrip-',dir=s))
freeze_variant(repo,check)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={str(p.relative_to(frozen)):sha(p) for p in files}
actual={str(p.relative_to(check)):sha(p) for p in check.rglob('*') if p.is_file()}
assert expected==actual
receipt={'selected':best,'files':expected,'effective_prompt_change':False,'source_synced_to_exact_evaluated_frozen_variant':True}
old=s/'delivery-prompt-roundtrip.json'
if old.exists():
 previous=json.loads(old.read_text())
 if previous['selected']!=best:
  backup=s/f'delivery-prompt-roundtrip-initial-{previous["selected"]}.json'
  assert not backup.exists()
  shutil.copy2(old,backup)
old.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'best':best,'verified_files':len(files),'effective_prompt_change':False}))
