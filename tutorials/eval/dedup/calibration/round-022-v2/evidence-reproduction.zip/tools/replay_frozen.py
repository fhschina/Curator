"""Replay immutable round-022 variants through the native evaluator in a fresh root."""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source-session', type=Path, required=True)
p.add_argument('--destination', type=Path, required=True)
p.add_argument('--checkout', type=Path, required=True)
p.add_argument('--endpoint', required=True)
p.add_argument('--container', required=True)
p.add_argument('--hours', type=float, default=8.0)
p.add_argument('--panels', nargs='+', default=['gate', 'coverage-regression', 'preflight', 'diagnostic', 'holdout'], choices=['gate', 'coverage-regression', 'preflight', 'diagnostic', 'holdout'])
p.add_argument('--repeats', nargs='+', default=[1, 2, 3], type=int, choices=[1, 2, 3])
a = p.parse_args()
if not 1 < a.hours <= 10:
    p.error('--hours must exceed the one-hour delivery reserve and not exceed ten')
if sys.prefix != '/raid/hfang/llm_judge_env_pr2324_latest':
    p.error('Use the existing /raid/hfang/llm_judge_env_pr2324_latest environment')
source = a.source_session.resolve()
selection = json.loads((source / 'final-selection.json').read_text())
best = selection['best_candidate']
destination = a.destination.resolve()
destination.mkdir(parents=True, exist_ok=False)
started = time.time()
(destination / 'SESSION_STATUS.json').write_text(json.dumps({'start_time': started, 'deadline': started+a.hours*3600, 'max_gpus': 1, 'source_session': str(source), 'purpose': 'frozen_replay_no_prompt_search'}, indent=2)+'\n')
(destination / 'service.json').write_text(json.dumps({'endpoint': a.endpoint, 'container': a.container}, indent=2)+'\n')

def copy_immutable(src, dst):
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)

for name in ['baseline', best]:
    src, dst = source / name, destination / name
    dst.mkdir()
    manifest = json.loads((src / 'manifest.json').read_text())
    files = set(manifest['files']) | {'manifest.json', 'private_index.json'}
    for filename in sorted(files):
        target = dst / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        copy_immutable(src / filename, target)
    env = {**os.environ, 'PYTHONPATH': str(a.checkout.resolve() / 'tutorials/eval/dedup')+':'+str(a.checkout.resolve())}
    command = [sys.executable, str(a.checkout.resolve() / 'tutorials/eval/dedup/policy_tuning.py'), 'execute', '--session', str(destination), '--root', str(dst), '--variant', 'baseline' if name == 'baseline' else 'candidate', '--panels', *a.panels, '--repeats', *map(str, a.repeats)]
    with (destination / f'{name}.log').open('w') as log:
        subprocess.run(command, cwd=a.checkout, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
print(json.dumps({'destination': str(destination), 'best_candidate': best, 'completed': time.time(), 'service_lifecycle': 'caller owned; stop the explicitly supplied service when finished'}))
