import json
import sys
from pathlib import Path

import data_designer.config as dd
import requests
import yaml
from data_designer.engine.column_generators.utils.prompt_renderer import (
    PromptType,
    RecordBasedPromptRenderer,
    create_response_recipe,
)
from policy_eval import read_rows

session = Path(__file__).resolve().parent
variant = Path(sys.argv[1])
judge = yaml.safe_load((variant / 'judge_config/fuzzy_pair_judge.yaml').read_text())['execution']['stages'][0]['judges'][0]
column = dd.LLMJudgeColumnConfig(
    name=judge['name'], model_alias='judge',
    prompt=(variant / 'judge_config/pair.jinja').read_text(),
    system_prompt=(variant / 'judge_config/system.jinja').read_text(),
    scores=[dd.Score(**value) for value in judge['scores']],
)
renderer = RecordBasedPromptRenderer(create_response_recipe(column))
row = next(row for row in read_rows(session / 'baseline/panels/diagnostic') if row['pair_id'] == 'D146')
messages = [
    {'role': 'system', 'content': renderer.render(prompt_template=column.system_prompt, record=row, prompt_type=PromptType.SYSTEM_PROMPT)},
    {'role': 'user', 'content': renderer.render(prompt_template=column.prompt, record=row, prompt_type=PromptType.USER_PROMPT)},
]
response = requests.post('http://127.0.0.1:18821/tokenize', json={
    'model': 'Qwen/Qwen3.8-27B-FP8', 'messages': messages,
    'add_generation_prompt': True, 'chat_template_kwargs': {'enable_thinking': False},
}, timeout=20)
response.raise_for_status()
count = response.json()['count']
result = {'variant': str(variant), 'pair_id': 'D146', 'prompt_tokens': count, 'max_tokens': 6144, 'context': 32768, 'headroom': 32768 - count - 6144}
print(json.dumps(result), flush=True)
if len(sys.argv) > 2:
    destination = Path(sys.argv[2])
    if destination.exists():
        raise ValueError('Use a new check artifact path')
    destination.write_text(json.dumps(result, indent=2) + '\n')
if result['headroom'] < 0:
    raise ValueError('Prompt plus fixed output budget exceeds the fixed context')
