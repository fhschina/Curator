import json
import signal
import socket
import subprocess
import time
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent
NAME = 'retention-policy-v2-20261027-gpu0'
PORT = 18821
IMAGE = 'ghcr.io/pst2154/nemotron-deciffusion@sha256:494aac2d7af43b7a70234792623a510bf29045a45b3aa893bc3170108ded9cea'
STATE = json.loads((ROOT / 'SESSION_STATUS.json').read_text())
assert time.time() < STATE['semantic_search_deadline']
assert subprocess.check_output(['nvidia-smi', '--id=0', '--query-gpu=memory.used', '--format=csv,noheader,nounits'], text=True).strip() == '0'
with socket.socket() as probe:
    probe.bind(('127.0.0.1', PORT))
CACHE = ROOT / 'service-cache'
CACHE.mkdir()
cmd = ['docker', 'run', '-d', '--name', NAME, '--label', 'codex.task=retention-policy-v2-20261027', '--gpus', 'device=0', '--ipc=host', '--log-opt', 'max-size=20m', '--log-opt', 'max-file=2', '-p', f'127.0.0.1:{PORT}:8000', '-v', '/raid/hfang/hf_cache/Qwen3.8-27B-FP8:/qwen:ro', '-v', f'{CACHE}:/cache', '-e', 'XDG_CACHE_HOME=/cache', '-e', 'HF_HUB_OFFLINE=1', '--entrypoint', 'vllm', IMAGE, 'serve', '/qwen', '--served-model-name', 'Qwen/Qwen3.8-27B-FP8', '--tensor-parallel-size', '1', '--dtype', 'auto', '--quantization', 'fp8', '--max-model-len', '32768', '--max-num-seqs', '8', '--gpu-memory-utilization', '0.8', '--enable-prefix-caching', '--host', '0.0.0.0', '--port', '8000', '--trust-remote-code']
started = time.time()
container = subprocess.check_output(cmd, text=True).strip()
record = {'container': NAME, 'container_id': container, 'endpoint': f'http://127.0.0.1:{PORT}/v1', 'started': started, 'deadline': STATE['deadline'], 'command': cmd, 'gpu': 0}
(ROOT / 'service.json').write_text(json.dumps(record, indent=2) + '\n')
print('STARTED', NAME, flush=True)
stopping = False

def stop(*_):
    global stopping
    stopping = True

signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
ready = False
try:
    while not stopping and time.time() < STATE['deadline']:
        if (ROOT / 'STOP_SERVICE').exists():
            break
        if not ready:
            try:
                response = requests.get(record['endpoint'] + '/models', timeout=3)
                if response.ok:
                    ready = True
                    record['ready'] = time.time()
                    (ROOT / 'service.json').write_text(json.dumps(record, indent=2) + '\n')
                    print('READY', flush=True)
            except requests.RequestException:
                pass
            if not ready and time.time() - started > 900:
                raise RuntimeError('Service did not become ready within 15 minutes')
        with (ROOT / 'gpu-usage.csv').open('a') as stream:
            usage = subprocess.check_output(['nvidia-smi', '--id=0', '--query-gpu=timestamp,uuid,memory.used,utilization.gpu,power.draw', '--format=csv,noheader'], text=True).strip()
            stream.write(f'{time.time()},{usage}\n')
        time.sleep(10)
finally:
    with (ROOT / 'service-final.log').open('w') as stream:
        subprocess.run(['docker', 'logs', NAME], stdout=stream, stderr=subprocess.STDOUT)
    subprocess.run(['docker', 'stop', '--time', '10', NAME], check=True)
    record['stopped'] = time.time()
    record['allocated_gpu_hours'] = (record['stopped'] - started) / 3600
    (ROOT / 'service.json').write_text(json.dumps(record, indent=2) + '\n')
    print('STOPPED', flush=True)
