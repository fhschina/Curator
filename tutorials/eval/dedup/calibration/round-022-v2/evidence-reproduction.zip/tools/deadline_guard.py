import json
import time
from pathlib import Path

session = Path(__file__).resolve().parent
deadline = json.loads((session / 'SESSION_STATUS.json').read_text())['deadline']
stop_at = deadline - 60
while time.time() < stop_at:
    service = json.loads((session / 'service.json').read_text())
    if service.get('stopped') or (session / 'STOP_SERVICE').exists():
        break
    time.sleep(min(20, max(1, stop_at - time.time())))
else:
    (session / 'STOP_SERVICE').write_text('Absolute ten-hour guard; reserve final shutdown minute.\n')
    (session / 'deadline-guard-stop.json').write_text(json.dumps({'stopped_requested': time.time(), 'original_deadline': deadline}) + '\n')
