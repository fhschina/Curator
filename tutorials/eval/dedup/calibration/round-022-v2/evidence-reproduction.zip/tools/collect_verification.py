import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

s=Path(__file__).resolve().parent
repo=Path('/raid/hfang/workspaces/Curator-retention-policy-v2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks={}
for name,filename,expected in [('tutorial_cpu','selected-tutorial-cpu-exact-means.log',70),('native_stage','final-native-stage.log',23),('workflow','final-workflow.log',32)]:
 p=s/filename
 text=p.read_text()
 passed=int(re.search(r'(\d+) passed',text).group(1))
 assert passed==expected and not re.search(r'\d+ (failed|error)',text,re.I),filename
 checks[name]={'result':'PASS','passed':passed,'log':str(p),'sha256':sha(p)}
gpu=json.loads((s/'gpu-checks.json').read_text())
checks['registered_single_gpu']={'result':'PASS' if gpu['exit_code']==0 and gpu['passed']==4 else 'FAIL','passed':gpu['passed'],'log':gpu['log'],'sha256':sha(gpu['log']),'receipt_sha256':sha(s/'gpu-checks.json')}
checks['tutorial_cpu']['command']='python -m pytest tests/tutorials/eval/dedup --confcutdir=tests/tutorials/eval/dedup -m \"not gpu\" -q'
checks['native_stage']['command']='python -m pytest tests/stages/synthetic/nemo_data_designer/test_data_designer.py --confcutdir=tests/stages/synthetic/nemo_data_designer -q'
checks['workflow']['command']='python -m pytest tests/eval/llm_judge/test_workflow.py --confcutdir=tests/eval/llm_judge -q'
checks['registered_single_gpu']['command']=gpu['command']
state=json.loads((s/'SESSION_STATUS.json').read_text())
assert len(state['semantic_candidates'])==6
selection=json.loads((s/'final-selection.json').read_text())
roundtrip=json.loads((s/'delivery-prompt-roundtrip.json').read_text())
assert roundtrip['selected']==selection['best_candidate']
assert roundtrip['source_synced_to_exact_evaluated_frozen_variant']
assert not roundtrip['effective_prompt_change']
write={'checked_at':time.time(),'checks':checks,'cpu_total':125,'gpu_test_scope':'Four registered single-GPU checks; eight-replica test excluded','precommit':'Final hook receipt is supplied separately after document/artifact generation','data_designer':'0.9.1','best_candidate':selection['best_candidate'],'prompt_roundtrip_receipt_sha256':sha(s/'delivery-prompt-roundtrip.json'),'hardware':subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=name,uuid,memory.total','--format=csv,noheader'],text=True).strip(),'native_python_unchanged_from':'6715574e4e553f7b36f263d755f6cebe198e7b11'}
(s/'verification-final.json').write_text(json.dumps(write,indent=2)+'\n')
print(json.dumps(write,indent=2))
