import json
from pathlib import Path
s=Path(__file__).resolve().parent
r=Path('/raid/hfang/workspaces/Curator-retention-policy-v2')
d=r/'tutorials/eval/dedup/calibration/round-022-v2'
c=json.loads((d/'summary.json').read_text());b=c['best_candidate']
selection=json.loads((d/'final-selection.json').read_text())
service=json.loads((d/'service.json').read_text())
pct=lambda x:f'{x*100:.2f}%'
rows=[]
for version in ['baseline',b]:
 for group in ['personal120','development99_original','development99_reviewed','development97_strict']:
  item=c['summary'][version][group]['final']
  rows.append(f'| {version} | {group} | {pct(item["direction_agreement"]["mean"])} | {pct(item["direction_agreement"]["worst"])} | {pct(item["pair_agreement"]["mean"])} | {pct(item["pair_agreement"]["worst"])} |')
text=f'''# Qwen retention calibration v2, round 022

**The task acceptance conditions were not met.** This is the best available
frozen version after six semantic candidates, delivered with all failed checks.
D121 remains pending. The fixed baseline is
`6715574e4e553f7b36f263d755f6cebe198e7b11`; the selected variant is `{b}`.

{selection['reason_en']}

Baseline and selected variant each completed all 150 discussion inputs and all
100 development inputs three times. Invalid and unresolved judgments remain
incorrect in their fixed eligible denominators. These are exposed development
references, not independent human accuracy or corpus deletion-risk estimates.
Allocated GPU use was {service['allocated_gpu_hours']:.2f} B200 hours on one GPU;
the owned service was stopped. The six-candidate search limit was reached; the
ten-hour wall-clock maximum was not exhausted.

| Version | Reference | Final direction mean | Direction worst | Final pair mean | Pair worst |
| --- | --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+f'''

The personal denominator is 120 pairs / 240 directions. The 100-input panel has
99 complete original references (H039 has an unresolved reference direction),
99 reviewed references accepting H029/H052 whole-pair alternatives, and 97 strict
reviewed references excluding those two ambiguous cases. All 100 inputs remain
in technical-validity counts. The reports distinguish the mean 80%/75% target
from the additional each-repeat stability check. Every hard-regression layer and
repetition must pass; no majority-vote acceptance is used.

## Reports and evidence

- [English report](../../../../../fern/versions/main/pages/curate-text/process-data/deduplication/retention-policy-v2-report-en.mdx)
  and [direct Chinese translation](../../../../../fern/versions/main/pages/curate-text/process-data/deduplication/retention-policy-v2-report-zh.mdx).
- Standalone [English HTML](report_en.html) and [Chinese HTML](report_zh.html).
- [Machine summary](summary.json), [per-run comparison CSV](comparison.csv),
  [machine HTML](comparison.html), and [shared report tables](report_tables.json).
- [Frozen manifest and hashes](manifest.json), [run provenance](run-provenance.json),
  [evaluation protocol](frozen-evaluation-protocol.json),
  [selection](final-selection.json), [engineering changes](engineering-changes.json),
  [verification](verification-final.json), and
  [translation verification](translation_validation.json).
- The ZIP archive(s) in this directory contain all six frozen prompt versions,
  the separate candidate-5 engineering repair, per-run JSON/CSV/HTML, original
  run manifests, review provenance, input indexes, and reproduction tools.
  The full comparison JSON is under `delivery/comparison.json` in the archive.

Full immutable input texts, native Data Designer outputs, HTTP attempt traces,
source snapshots and checkpoints remain at:

```text
{s}
```

Per-row CSVs preserve historical reference columns even for unscored rows;
scoring eligibility is defined by the frozen evaluation lists and aggregate
groups, not by the mere presence of a historical reference.

Raw corpus text and HTTP bodies are not committed. No new 20K or Deciffusion
inference was run. Their frozen historical input hashes do not indicate new
inference. The original round-021 reports and branch remain intact.

## Recompute the comparison without inference

Use the existing environment and this checkout. Choose a new output directory;
the evaluator refuses to overwrite an existing comparison or inference run.

```bash
cd {r}
export PATH=/raid/hfang/llm_judge_env_pr2324_latest/bin:$PATH
export PYTHONPATH={r}/tutorials/eval/dedup:{r}
python tutorials/eval/dedup/policy_tuning.py compare \\
  --session {s} \\
  --best {int(b[10:12])} --best-root {b} --output NEW_UNIQUE_COMPARISON
```

To rebuild both human reports from that comparison, extract the ZIP archive(s)
into one new directory and run its shared renderer, supplying the original
session explicitly:

```bash
python EXTRACTED/tools/render_bilingual.py \\
  {s}/NEW_UNIQUE_COMPARISON/comparison.json \\
  NEW_UNIQUE_HUMAN_REPORT_DIRECTORY \\
  {s}
```

The renderer checks common table data, section order and numeric equality across
languages. It requires three completed baseline and selected-variant diagnostic
and development repetitions, plus the frozen selection and verification receipts.

## Replay inference with frozen prompts

First provide one caller-owned GPU0 service using the exact profile in
[service.json](service.json): the pinned image and Qwen revision, FP8, TP=1,
context 32768, max sequences 8, memory fraction 0.8, and the read-only checkpoint
mount. Use a unique container name, loopback port and cache directory, and an
absolute shutdown deadline. The recorded supervisor and deadline-guard sources
are included as evidence; their original names and expired deadline must be
adapted for a new replay. The native evaluator verifies the live service profile.

With that service ready, run the archived replay script in the existing
`/raid/hfang/llm_judge_env_pr2324_latest` environment:

```bash
python EXTRACTED/tools/replay_frozen.py \\
  --source-session {s} \\
  --destination /absolute/path/to/NEW_UNIQUE_REPLAY \\
  --checkout {r} \\
  --endpoint http://127.0.0.1:NEW_PORT/v1 --container NEW_OWNED_CONTAINER \\
  --hours 8 --repeats 1 2 3
```

This creates fresh run directories and checkpoints, links/copies only immutable
frozen inputs, and calls `policy_tuning.py execute` followed by the original
`policy_eval.py run`. It performs no prompt search and does not create or sync an
environment. Native parameters remain max_tokens=6144, temperature=0.2,
concurrency=8, timeout=600, thinking disabled, and the fixed 6000-character window.
Keep the caller-owned service's lifecycle receipt and stop it when replay ends.
Recompute its comparison using the command above with the new session path.

## Validation

CPU tests cover fixed denominators, coherent accepted pairs, retained failures,
raw unsafe signals, actual template compilation, evidence/window rendering, the
native Data Designer stage and workflow. Registered GPU checks exercise actual
structured generation/SkipConfig, untrusted document instructions, coverage
proof and subject verification. Only the single-GPU checks were run; the
registered eight-replica check was excluded. Exact results and log hashes are in
`verification-final.json`; final hook evidence accompanies the delivery.
'''
(d/'README.md').write_text(text)
print(d/'README.md')
